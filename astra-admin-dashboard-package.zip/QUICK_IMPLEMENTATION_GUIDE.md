# ⚡ Quick Implementation Guide - Admin Dashboard

**Time to implement: ~15 minutes**

---

## 🎯 TL;DR

1. Copy enhanced admin page to `/app/admin-ops/page.tsx`
2. Add `role` field to User model
3. Create API routes in `/app/api/admin/`
4. Make your user an admin via MongoDB
5. Test the dashboard!

---

## 📋 Prerequisites

✅ Next.js 14+  
✅ NextAuth v5  
✅ MongoDB + Mongoose  
✅ Tailwind CSS  
✅ Framer Motion  
✅ Lucide React  

---

## 🚀 Step 1: Update User Model (2 min)

**File:** `models/User.ts`

```typescript
import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  email: { 
    type: String, 
    required: true, 
    unique: true 
  },
  name: String,
  password: String,
  
  // ADD THESE FIELDS ↓↓↓
  role: { 
    type: String, 
    enum: ['user', 'moderator', 'admin'],
    default: 'user'
  },
  status: { 
    type: String, 
    enum: ['active', 'inactive'],
    default: 'active'
  },
  lastActive: { 
    type: Date, 
    default: Date.now 
  },
  // ↑↑↑ ADD THESE FIELDS
  
  createdAt: { 
    type: Date, 
    default: Date.now 
  }
});

export default mongoose.models.User || mongoose.model('User', userSchema);
```

---

## 🎨 Step 2: Replace Admin Page (3 min)

**File:** `app/admin-ops/page.tsx`

- Delete all content in the current file
- Paste the entire enhanced admin dashboard component from `admin-dashboard-enhanced.tsx`
- Make sure it stays as a `'use client'` component

---

## 🔌 Step 3: Create API Routes (8 min)

### Route 1: Users API
**File:** `app/api/admin/users/route.ts`

```typescript
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/auth';
import User from '@/models/User';
import { connectMongoDB } from '@/lib/mongodb';

async function checkAdminAccess(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
      return { authorized: false, error: 'Not authenticated' };
    }

    await connectMongoDB();
    const user = await User.findOne({ email: session.user.email });

    if (!user || user.role !== 'admin') {
      return { authorized: false, error: 'Admin access required' };
    }

    return { authorized: true, user };
  } catch (error) {
    return { authorized: false, error: 'Authentication failed' };
  }
}

export async function GET(req: NextRequest) {
  try {
    const auth = await checkAdminAccess(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error }, { status: 401 });
    }

    await connectMongoDB();
    const users = await User.find()
      .select('-password')
      .sort({ createdAt: -1 })
      .lean();

    return NextResponse.json({
      success: true,
      data: users,
      count: users.length
    });
  } catch (error: any) {
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}
```

### Route 2: Update User Role
**File:** `app/api/admin/users/[id]/role/route.ts`

```typescript
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/auth';
import User from '@/models/User';
import { connectMongoDB } from '@/lib/mongodb';

async function checkAdminAccess(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) {
    return { authorized: false };
  }
  await connectMongoDB();
  const user = await User.findOne({ email: session.user.email });
  if (!user || user.role !== 'admin') {
    return { authorized: false };
  }
  return { authorized: true, user };
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const auth = await checkAdminAccess(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    await connectMongoDB();
    const body = await req.json();

    const validRoles = ['user', 'moderator', 'admin'];
    if (!validRoles.includes(body.role)) {
      return NextResponse.json(
        { error: 'Invalid role' },
        { status: 400 }
      );
    }

    const user = await User.findByIdAndUpdate(
      params.id,
      { role: body.role },
      { new: true }
    ).select('-password');

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      message: `User role updated to ${body.role}`,
      data: user
    });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}
```

### Route 3: Tracks API
**File:** `app/api/admin/tracks/route.ts`

```typescript
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/auth';
import Track from '@/models/Track';
import User from '@/models/User';
import { connectMongoDB } from '@/lib/mongodb';

async function checkAdminAccess(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return { authorized: false };
  await connectMongoDB();
  const user = await User.findOne({ email: session.user.email });
  if (!user || user.role !== 'admin') return { authorized: false };
  return { authorized: true, user };
}

export async function GET(req: NextRequest) {
  try {
    const auth = await checkAdminAccess(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    await connectMongoDB();
    const tracks = await Track.find().sort({ createdAt: -1 }).lean();

    return NextResponse.json({
      success: true,
      data: tracks,
      count: tracks.length
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const auth = await checkAdminAccess(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    await connectMongoDB();
    const body = await req.json();

    if (!body.name || !body.description) {
      return NextResponse.json(
        { error: 'Name and description required' },
        { status: 400 }
      );
    }

    const track = new Track({
      name: body.name,
      category: body.category || 'Technology',
      difficulty: body.difficulty || 'Intermediate',
      estimatedHours: body.estimatedHours || 40,
      modulesCount: body.modulesCount || 8,
      description: body.description,
      prerequisites: body.prerequisites || '',
      createdAt: new Date()
    });

    await track.save();

    return NextResponse.json({
      success: true,
      message: 'Track created',
      data: track
    }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
```

### Route 4: Delete Track
**File:** `app/api/admin/tracks/[id]/route.ts`

```typescript
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/auth';
import Track from '@/models/Track';
import User from '@/models/User';
import { connectMongoDB } from '@/lib/mongodb';

async function checkAdminAccess(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return { authorized: false };
  await connectMongoDB();
  const user = await User.findOne({ email: session.user.email });
  if (!user || user.role !== 'admin') return { authorized: false };
  return { authorized: true };
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const auth = await checkAdminAccess(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    await connectMongoDB();
    const track = await Track.findByIdAndDelete(params.id);

    if (!track) {
      return NextResponse.json({ error: 'Track not found' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      message: 'Track deleted'
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const auth = await checkAdminAccess(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    await connectMongoDB();
    const body = await req.json();
    const track = await Track.findByIdAndUpdate(params.id, body, { new: true });

    if (!track) {
      return NextResponse.json({ error: 'Track not found' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      message: 'Track updated',
      data: track
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
```

### Route 5: Opportunities (Similar to Tracks)
**File:** `app/api/admin/opportunities/route.ts`

```typescript
// Same structure as tracks route
// Just replace Track model with Opportunity model
import Opportunity from '@/models/Opportunity';

// GET and POST handlers for opportunities
```

---

## 🔐 Step 4: Make First User Admin (2 min)

### Option A: MongoDB Direct (Fastest)

Open MongoDB Compass or use CLI:

```javascript
db.users.updateOne(
  { email: "your-email@gmail.com" },
  { $set: { role: "admin" } }
)
```

### Option B: Create Admin Script

**File:** `scripts/make-admin.ts`

```typescript
import { connectMongoDB } from '@/lib/mongodb';
import User from '@/models/User';

async function makeAdmin(email: string) {
  await connectMongoDB();
  const user = await User.findOneAndUpdate(
    { email },
    { role: 'admin' },
    { new: true }
  );
  console.log('✅ Admin created:', user.email);
  process.exit(0);
}

// Run: npx ts-node scripts/make-admin.ts your-email@gmail.com
const email = process.argv[2];
if (!email) {
  console.error('Usage: npx ts-node scripts/make-admin.ts your-email@gmail.com');
  process.exit(1);
}
makeAdmin(email);
```

---

## 🧪 Step 5: Test It Out (1 min)

1. **Login** to your app with your admin account
2. **Navigate** to `/admin-ops`
3. **Check** if dashboard loads
4. **Try** creating a track
5. **Try** changing user role
6. **Check** notifications appear

---

## ✅ Verification Checklist

- [ ] User model has `role` field
- [ ] Admin page replaced at `/app/admin-ops/page.tsx`
- [ ] API routes created in `/app/api/admin/`
- [ ] Your user is set to `role: 'admin'`
- [ ] Can access `/admin-ops` without redirect
- [ ] Dashboard displays correctly
- [ ] Can create tracks/opportunities
- [ ] Can change user roles
- [ ] Can delete items
- [ ] Notifications appear

---

## 🐛 Debugging

### Dashboard won't load
```bash
# Check browser console for errors
# Verify you're logged in
# Check if user.role === 'admin' in MongoDB
```

### API returns 401 Unauthorized
```bash
# Verify NextAuth session is valid
# Check if User model has role field
# Ensure admin check function works
```

### Styles not showing
```bash
# Verify Tailwind CSS is configured
# Check if Framer Motion is installed
# Run: npm install framer-motion
```

### Data not saving
```bash
# Check MongoDB connection
# Verify models are properly imported
# Check if collections exist in MongoDB
```

---

## 🎨 Customizations

### Change Colors
Replace in admin-dashboard-enhanced.tsx:
```typescript
// Blue → Change to purple
from-blue-600 to-cyan-600
// Becomes:
from-purple-600 to-pink-600
```

### Change Sidebar Width
```typescript
sidebarOpen ? 'w-64' : 'w-20'
// Change to:
sidebarOpen ? 'w-80' : 'w-24'
```

### Add More Tabs
```typescript
const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'tracks' | 'opportunities' | 'settings' | 'reports'>('overview');

// Add 'reports' to the nav items
```

---

## 📚 Next Steps

1. **Connect API calls** to real data:
   ```typescript
   // Replace mock data with actual API calls
   const usersRes = await fetch('/api/admin/users');
   const users = await usersRes.json();
   setUsers(users.data);
   ```

2. **Add analytics**:
   - Real-time enrollment counts
   - Application statistics
   - User growth charts

3. **Add more features**:
   - Activity logs
   - User notifications
   - Email campaigns
   - Batch operations

4. **Enhance security**:
   - Add audit logs
   - Rate limiting
   - IP whitelisting
   - 2FA for admin

---

## 🎉 You're Done!

Your admin dashboard is now fully functional! 

**What you can do:**
- ✅ Manage users & roles
- ✅ Create/edit/delete tracks
- ✅ Post opportunities
- ✅ View analytics
- ✅ Export data
- ✅ Control platform

**Happy Admin-ing!** 🚀

---

## 💬 Need Help?

1. Check the `ADMIN_DASHBOARD_SETUP.md` for detailed docs
2. Review error messages in console
3. Verify all files are in correct locations
4. Check MongoDB for data
5. Review NextAuth configuration

---

## 📞 Files Created

- ✅ `admin-dashboard-enhanced.tsx` - Main dashboard component
- ✅ `app-api-admin-users-route.ts` - Users API
- ✅ `app-api-admin-tracks-route.ts` - Tracks API
- ✅ `app-api-admin-opportunities-route.ts` - Opportunities API
- ✅ `ADMIN_DASHBOARD_SETUP.md` - Full setup guide
- ✅ `QUICK_IMPLEMENTATION_GUIDE.md` - This file

Copy paste & follow along! 💪
