// app/api/admin/tracks/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/auth';
import Track from '@/models/Track';
import User from '@/models/User';
import { connectMongoDB } from '@/lib/mongodb';

// Middleware to check admin access
async function checkAdminAccess(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.email) {
      return { authorized: false, error: 'Not authenticated' };
    }

    await connectMongoDB();
    const user = await User.findOne({ email: session.user.email });

    if (!user || user.role !== 'admin') {
      return { authorized: false, error: 'Admin access required' };
    }

    return { authorized: true, user };
  } catch (error) {
    return { authorized: false, error: 'Authentication failed' };
  }
}

// GET all tracks with optional filters
export async function GET(req: NextRequest) {
  try {
    const auth = await checkAdminAccess(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error }, { status: 401 });
    }

    await connectMongoDB();
    
    // Optional filters
    const searchParams = req.nextUrl.searchParams;
    const category = searchParams.get('category');
    const difficulty = searchParams.get('difficulty');

    let query: any = {};
    if (category) query.category = category;
    if (difficulty) query.difficulty = difficulty;

    const tracks = await Track.find(query).sort({ createdAt: -1 }).lean();

    return NextResponse.json({
      success: true,
      data: tracks,
      count: tracks.length,
      message: `Retrieved ${tracks.length} tracks`
    });
  } catch (error: any) {
    console.error('Error fetching tracks:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to fetch tracks' },
      { status: 500 }
    );
  }
}

// POST - Create new track
export async function POST(req: NextRequest) {
  try {
    const auth = await checkAdminAccess(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error }, { status: 401 });
    }

    await connectMongoDB();
    const body = await req.json();

    // Validation
    if (!body.name || !body.description) {
      return NextResponse.json(
        { success: false, error: 'Name and description are required' },
        { status: 400 }
      );
    }

    const track = new Track({
      name: body.name,
      category: body.category || 'Technology',
      difficulty: body.difficulty || 'Intermediate',
      estimatedHours: body.estimatedHours || 40,
      modulesCount: body.modulesCount || 8,
      description: body.description,
      prerequisites: body.prerequisites || '',
      enrollmentCount: 0,
      createdAt: new Date(),
      createdBy: auth.user._id
    });

    await track.save();

    return NextResponse.json({
      success: true,
      message: 'Track created successfully',
      data: track
    }, { status: 201 });
  } catch (error: any) {
    console.error('Error creating track:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to create track' },
      { status: 500 }
    );
  }
}

// ============================================
// app/api/admin/tracks/[id]/route.ts
// ============================================

// PATCH - Update track
export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const auth = await checkAdminAccess(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error }, { status: 401 });
    }

    await connectMongoDB();
    const body = await req.json();

    const track = await Track.findByIdAndUpdate(
      params.id,
      {
        ...body,
        updatedAt: new Date()
      },
      { new: true }
    );

    if (!track) {
      return NextResponse.json(
        { success: false, error: 'Track not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: 'Track updated successfully',
      data: track
    });
  } catch (error: any) {
    console.error('Error updating track:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to update track' },
      { status: 500 }
    );
  }
}

// DELETE - Delete track
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const auth = await checkAdminAccess(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error }, { status: 401 });
    }

    await connectMongoDB();
    const track = await Track.findByIdAndDelete(params.id);

    if (!track) {
      return NextResponse.json(
        { success: false, error: 'Track not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: 'Track deleted successfully',
      data: track
    });
  } catch (error: any) {
    console.error('Error deleting track:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to delete track' },
      { status: 500 }
    );
  }
}
