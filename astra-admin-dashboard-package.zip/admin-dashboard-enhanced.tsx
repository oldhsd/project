'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { signOut } from 'next-auth/react';
import Link from 'next/link';
import { 
  BarChart3, 
  BookOpen, 
  BriefcaseBusiness,
  Users,
  LogOut,
  Menu,
  X,
  Settings,
  Shield,
  TrendingUp,
  Eye,
  Edit,
  Trash2,
  Plus,
  Search,
  Filter,
  Download,
  Bell,
  CheckCircle2,
  AlertCircle,
  Clock,
  DollarSign,
  Calendar,
  MapPin,
  GraduationCap,
  Award,
  MoreVertical,
  ChevronRight,
  Activity
} from 'lucide-react';
import { motion } from 'framer-motion';

interface AdminUser {
  _id: string;
  email: string;
  name: string;
  role: 'admin' | 'moderator' | 'user';
  createdAt: string;
  status: 'active' | 'inactive';
  lastActive: string;
}

interface Track {
  _id?: string;
  name: string;
  category: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  estimatedHours: number;
  modulesCount: number;
  description: string;
  prerequisites: string;
  enrollmentCount?: number;
  createdAt?: string;
}

interface Opportunity {
  _id?: string;
  title: string;
  company: string;
  type: 'Internship' | 'Full-time' | 'Freelance' | 'Scholarship';
  mode: 'Remote' | 'Onsite' | 'Hybrid';
  location: string;
  stipend: string;
  description: string;
  skills: string;
  eligibility: string;
  deadline: string;
  applicationsCount?: number;
  createdAt?: string;
}

export default function EnhancedAdminDashboard() {
  const router = useRouter();
  const { data: session, status } = useSession();
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'tracks' | 'opportunities' | 'settings'>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState<'track' | 'opportunity'>('track');
  
  // Data states
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [tracks, setTracks] = useState<Track[]>([]);
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [analytics, setAnalytics] = useState({
    totalUsers: 0,
    totalTracks: 0,
    totalOpportunities: 0,
    activeEnrollments: 0,
    pendingApplications: 0,
    platformGrowth: 24
  });

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRole, setSelectedRole] = useState<'all' | 'admin' | 'moderator' | 'user'>('all');
  const [loading, setLoading] = useState(true);
  const [notifications, setNotifications] = useState<Array<{id: string; message: string; type: 'success' | 'error' | 'info'}>>([]);

  // Form states
  const [trackForm, setTrackForm] = useState<Track>({
    name: '',
    category: 'Technology',
    difficulty: 'Intermediate',
    estimatedHours: 40,
    modulesCount: 8,
    description: '',
    prerequisites: ''
  });

  const [opportunityForm, setOpportunityForm] = useState<Opportunity>({
    title: '',
    company: '',
    type: 'Internship',
    mode: 'Remote',
    location: '',
    stipend: '',
    description: '',
    skills: '',
    eligibility: '',
    deadline: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  });

  // Check admin access
  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    // Add admin role check here based on your auth setup
  }, [status, router]);

  // Fetch data
  useEffect(() => {
    const fetchAllData = async () => {
      try {
        setLoading(true);
        // Fetch from your APIs
        // const usersRes = await fetch('/api/admin/users');
        // const tracksRes = await fetch('/api/admin/tracks');
        // const oppRes = await fetch('/api/admin/opportunities');
        
        // Mock data for demonstration - remove when connecting to real API
        setUsers([
          {
            _id: '1',
            email: 'admin@buildnext.com',
            name: 'Admin User',
            role: 'admin',
            status: 'active',
            createdAt: new Date().toISOString(),
            lastActive: new Date().toISOString()
          }
        ]);

        setTracks([]);
        setOpportunities([]);
        setAnalytics({
          totalUsers: 1,
          totalTracks: 0,
          totalOpportunities: 0,
          activeEnrollments: 0,
          pendingApplications: 0,
          platformGrowth: 0
        });

        setLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        addNotification('Failed to load data', 'error');
        setLoading(false);
      }
    };

    if (status === 'authenticated') {
      fetchAllData();
    }
  }, [status]);

  const addNotification = (message: string, type: 'success' | 'error' | 'info') => {
    const id = Date.now().toString();
    setNotifications(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 3000);
  };

  const handleAddTrack = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      // Call your API: await fetch('/api/admin/tracks', { method: 'POST', body: JSON.stringify(trackForm) })
      addNotification('Track added successfully', 'success');
      setTrackForm({
        name: '',
        category: 'Technology',
        difficulty: 'Intermediate',
        estimatedHours: 40,
        modulesCount: 8,
        description: '',
        prerequisites: ''
      });
      setShowModal(false);
    } catch (error) {
      addNotification('Failed to add track', 'error');
    }
  };

  const handleAddOpportunity = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      // Call your API: await fetch('/api/admin/opportunities', { method: 'POST', body: JSON.stringify(opportunityForm) })
      addNotification('Opportunity added successfully', 'success');
      setOpportunityForm({
        title: '',
        company: '',
        type: 'Internship',
        mode: 'Remote',
        location: '',
        stipend: '',
        description: '',
        skills: '',
        eligibility: '',
        deadline: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
      });
      setShowModal(false);
    } catch (error) {
      addNotification('Failed to add opportunity', 'error');
    }
  };

  const handleRoleChange = async (userId: string, newRole: 'admin' | 'moderator' | 'user') => {
    try {
      // await fetch(`/api/admin/users/${userId}/role`, { method: 'PATCH', body: JSON.stringify({ role: newRole }) })
      addNotification(`User role updated to ${newRole}`, 'success');
    } catch (error) {
      addNotification('Failed to update user role', 'error');
    }
  };

  const handleDeleteItem = async (id: string, type: 'track' | 'opportunity') => {
    if (!confirm(`Are you sure you want to delete this ${type}?`)) return;
    try {
      // await fetch(`/api/admin/${type}s/${id}`, { method: 'DELETE' })
      if (type === 'track') {
        setTracks(prev => prev.filter(t => t._id !== id));
      } else {
        setOpportunities(prev => prev.filter(o => o._id !== id));
      }
      addNotification(`${type} deleted successfully`, 'success');
    } catch (error) {
      addNotification(`Failed to delete ${type}`, 'error');
    }
  };

  if (status === 'loading' || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        <div className="text-center">
          <div className="mb-4 flex justify-center">
            <div className="w-12 h-12 rounded-full border-4 border-blue-500/20 border-t-blue-500 animate-spin"></div>
          </div>
          <p className="text-slate-400 font-medium">Loading admin panel...</p>
        </div>
      </div>
    );
  }

  if (status === 'unauthenticated') {
    return null;
  }

  return (
    <div className="flex h-screen bg-slate-900">
      {/* Sidebar */}
      <motion.div
        className={`${
          sidebarOpen ? 'w-64' : 'w-20'
        } bg-gradient-to-b from-slate-800 to-slate-900 border-r border-slate-700 transition-all duration-300 flex flex-col`}
        initial={false}
      >
        {/* Logo */}
        <div className="h-16 border-b border-slate-700 flex items-center justify-between px-4">
          {sidebarOpen && <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">BuildNext</h1>}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
          >
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2">
          {[
            { id: 'overview', label: 'Overview', icon: BarChart3 },
            { id: 'users', label: 'Users', icon: Users },
            { id: 'tracks', label: 'Tracks', icon: BookOpen },
            { id: 'opportunities', label: 'Opportunities', icon: BriefcaseBusiness },
            { id: 'settings', label: 'Settings', icon: Settings }
          ].map(item => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as any)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                  activeTab === item.id
                    ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-lg'
                    : 'text-slate-400 hover:bg-slate-700 hover:text-white'
                }`}
              >
                <Icon size={20} />
                {sidebarOpen && <span className="text-sm font-medium">{item.label}</span>}
              </button>
            );
          })}
        </nav>

        {/* User Info & Logout */}
        <div className="p-4 border-t border-slate-700">
          {sidebarOpen && (
            <div className="mb-4 p-3 bg-slate-700/50 rounded-lg">
              <p className="text-xs text-slate-400">Logged as</p>
              <p className="text-sm font-medium text-white truncate">{session?.user?.email}</p>
            </div>
          )}
          <button
            onClick={() => signOut({ redirect: true, callbackUrl: '/' })}
            className="w-full flex items-center gap-3 px-4 py-2 rounded-lg text-red-400 hover:bg-red-500/10 transition-colors"
          >
            <LogOut size={20} />
            {sidebarOpen && <span className="text-sm font-medium">Logout</span>}
          </button>
        </div>
      </motion.div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto flex flex-col">
        {/* Top Bar */}
        <div className="h-16 border-b border-slate-700 bg-slate-800/50 backdrop-blur flex items-center justify-between px-8 sticky top-0 z-10">
          <h2 className="text-2xl font-bold text-white capitalize">{activeTab}</h2>
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search size={20} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>
            <button className="p-2 hover:bg-slate-700 rounded-lg transition-colors relative">
              <Bell size={20} className="text-slate-400" />
              {notifications.length > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              )}
            </button>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 p-8 space-y-6">
          {/* Notifications */}
          <div className="fixed top-20 right-8 space-y-2 z-50">
            {notifications.map(notif => (
              <motion.div
                key={notif.id}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className={`px-4 py-3 rounded-lg flex items-center gap-3 text-sm font-medium ${
                  notif.type === 'success' ? 'bg-green-500/20 text-green-300 border border-green-500/30' :
                  notif.type === 'error' ? 'bg-red-500/20 text-red-300 border border-red-500/30' :
                  'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                }`}
              >
                {notif.type === 'success' && <CheckCircle2 size={18} />}
                {notif.type === 'error' && <AlertCircle size={18} />}
                {notif.type === 'info' && <Activity size={18} />}
                {notif.message}
              </motion.div>
            ))}
          </div>

          {/* OVERVIEW TAB */}
          {activeTab === 'overview' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[
                  { label: 'Total Users', value: analytics.totalUsers, icon: Users, color: 'from-blue-600 to-cyan-600' },
                  { label: 'Total Tracks', value: analytics.totalTracks, icon: BookOpen, color: 'from-purple-600 to-pink-600' },
                  { label: 'Opportunities', value: analytics.totalOpportunities, icon: BriefcaseBusiness, color: 'from-orange-600 to-red-600' },
                  { label: 'Active Enrollments', value: analytics.activeEnrollments, icon: TrendingUp, color: 'from-green-600 to-emerald-600' },
                  { label: 'Pending Applications', value: analytics.pendingApplications, icon: Clock, color: 'from-yellow-600 to-orange-600' },
                  { label: 'Platform Growth', value: `${analytics.platformGrowth}%`, icon: BarChart3, color: 'from-indigo-600 to-purple-600' }
                ].map((stat, idx) => {
                  const Icon = stat.icon;
                  return (
                    <motion.div
                      key={idx}
                      whileHover={{ scale: 1.02 }}
                      className={`p-6 rounded-xl bg-gradient-to-br ${stat.color} border border-white/10 shadow-lg hover:shadow-2xl transition-all`}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="text-white/70 text-sm font-medium">{stat.label}</p>
                          <p className="text-3xl font-bold text-white mt-2">{stat.value}</p>
                        </div>
                        <Icon size={28} className="text-white/50" />
                      </div>
                    </motion.div>
                  );
                })}
              </div>

              {/* Quick Actions */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  onClick={() => { setModalType('track'); setShowModal(true); }}
                  className="p-6 rounded-xl bg-gradient-to-br from-blue-600/20 to-cyan-600/20 border border-blue-500/30 hover:border-blue-500/60 transition-all"
                >
                  <Plus size={24} className="text-blue-400 mb-2" />
                  <p className="text-white font-semibold">Add New Track</p>
                  <p className="text-slate-400 text-sm mt-1">Create a learning pathway</p>
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  onClick={() => { setModalType('opportunity'); setShowModal(true); }}
                  className="p-6 rounded-xl bg-gradient-to-br from-orange-600/20 to-red-600/20 border border-orange-500/30 hover:border-orange-500/60 transition-all"
                >
                  <Plus size={24} className="text-orange-400 mb-2" />
                  <p className="text-white font-semibold">Add Opportunity</p>
                  <p className="text-slate-400 text-sm mt-1">Post a new job or internship</p>
                </motion.button>
              </div>
            </motion.div>
          )}

          {/* USERS TAB */}
          {activeTab === 'users' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              {/* Filters */}
              <div className="flex items-center gap-4">
                <select
                  value={selectedRole}
                  onChange={(e) => setSelectedRole(e.target.value as any)}
                  className="px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="all">All Roles</option>
                  <option value="admin">Admin</option>
                  <option value="moderator">Moderator</option>
                  <option value="user">User</option>
                </select>
              </div>

              {/* Users Table */}
              <div className="rounded-xl border border-slate-700 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-slate-800/50 border-b border-slate-700">
                        <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Email</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Name</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Role</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Status</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Last Active</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-700">
                      {users.map(user => (
                        <tr key={user._id} className="hover:bg-slate-800/30 transition-colors">
                          <td className="px-6 py-4 text-sm text-white">{user.email}</td>
                          <td className="px-6 py-4 text-sm text-white">{user.name}</td>
                          <td className="px-6 py-4">
                            <select
                              value={user.role}
                              onChange={(e) => handleRoleChange(user._id, e.target.value as any)}
                              className="px-2 py-1 bg-slate-700 border border-slate-600 rounded text-xs text-white focus:outline-none focus:border-blue-500"
                            >
                              <option value="user">User</option>
                              <option value="moderator">Moderator</option>
                              <option value="admin">Admin</option>
                            </select>
                          </td>
                          <td className="px-6 py-4">
                            <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                              user.status === 'active' 
                                ? 'bg-green-500/20 text-green-300' 
                                : 'bg-red-500/20 text-red-300'
                            }`}>
                              {user.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-sm text-slate-400">{new Date(user.lastActive).toLocaleDateString()}</td>
                          <td className="px-6 py-4">
                            <button className="p-1 hover:bg-slate-700 rounded transition-colors">
                              <MoreVertical size={18} className="text-slate-400" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </motion.div>
          )}

          {/* TRACKS TAB */}
          {activeTab === 'tracks' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <button
                onClick={() => { setModalType('track'); setShowModal(true); }}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg hover:shadow-lg transition-all"
              >
                <Plus size={18} /> Add Track
              </button>

              {/* Tracks Grid */}
              {tracks.length === 0 ? (
                <div className="text-center py-12">
                  <BookOpen size={48} className="mx-auto text-slate-600 mb-4" />
                  <p className="text-slate-400">No tracks added yet. Create one to get started!</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {tracks.map(track => (
                    <motion.div
                      key={track._id}
                      whileHover={{ scale: 1.02 }}
                      className="p-6 rounded-xl bg-slate-800 border border-slate-700 hover:border-blue-500/50 transition-all"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <h3 className="text-lg font-bold text-white flex-1">{track.name}</h3>
                        <button className="p-1 hover:bg-slate-700 rounded transition-colors">
                          <Trash2 size={18} className="text-red-400" />
                        </button>
                      </div>
                      <p className="text-slate-400 text-sm mb-4">{track.description}</p>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between text-slate-300">
                          <span>Category:</span>
                          <span className="font-medium">{track.category}</span>
                        </div>
                        <div className="flex justify-between text-slate-300">
                          <span>Difficulty:</span>
                          <span className="font-medium">{track.difficulty}</span>
                        </div>
                        <div className="flex justify-between text-slate-300">
                          <span>Duration:</span>
                          <span className="font-medium">{track.estimatedHours}h</span>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          )}

          {/* OPPORTUNITIES TAB */}
          {activeTab === 'opportunities' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <button
                onClick={() => { setModalType('opportunity'); setShowModal(true); }}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-600 to-red-600 text-white rounded-lg hover:shadow-lg transition-all"
              >
                <Plus size={18} /> Add Opportunity
              </button>

              {/* Opportunities List */}
              {opportunities.length === 0 ? (
                <div className="text-center py-12">
                  <BriefcaseBusiness size={48} className="mx-auto text-slate-600 mb-4" />
                  <p className="text-slate-400">No opportunities posted yet. Create one to get started!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {opportunities.map(opp => (
                    <motion.div
                      key={opp._id}
                      whileHover={{ scale: 1.01 }}
                      className="p-6 rounded-xl bg-slate-800 border border-slate-700 hover:border-orange-500/50 transition-all"
                    >
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="text-lg font-bold text-white">{opp.title}</h3>
                          <p className="text-slate-400 text-sm">{opp.company}</p>
                        </div>
                        <button className="p-1 hover:bg-slate-700 rounded transition-colors">
                          <Trash2 size={18} className="text-red-400" />
                        </button>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-slate-400 text-xs">Type</p>
                          <p className="text-white font-medium">{opp.type}</p>
                        </div>
                        <div>
                          <p className="text-slate-400 text-xs">Mode</p>
                          <p className="text-white font-medium">{opp.mode}</p>
                        </div>
                        <div>
                          <p className="text-slate-400 text-xs">Stipend</p>
                          <p className="text-white font-medium">{opp.stipend}</p>
                        </div>
                        <div>
                          <p className="text-slate-400 text-xs">Deadline</p>
                          <p className="text-white font-medium">{new Date(opp.deadline).toLocaleDateString()}</p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          )}

          {/* SETTINGS TAB */}
          {activeTab === 'settings' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6 max-w-2xl"
            >
              <div className="rounded-xl border border-slate-700 p-6 bg-slate-800/50">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <Shield size={24} /> Admin Settings
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Platform Name</label>
                    <input type="text" defaultValue="BuildNext" className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Platform URL</label>
                    <input type="text" defaultValue="https://build-next.onrender.com" className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500" />
                  </div>
                  <div>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" defaultChecked className="w-4 h-4 rounded border-slate-600" />
                      <span className="text-slate-300">Enable user registrations</span>
                    </label>
                  </div>
                  <div>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" defaultChecked className="w-4 h-4 rounded border-slate-600" />
                      <span className="text-slate-300">Enable opportunity applications</span>
                    </label>
                  </div>
                </div>
              </div>

              <button className="px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-semibold rounded-lg hover:shadow-lg transition-all">
                Save Settings
              </button>
            </motion.div>
          )}
        </div>
      </div>

      {/* Add Track Modal */}
      {showModal && modalType === 'track' && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-slate-800 rounded-xl border border-slate-700 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
          >
            <div className="p-6 border-b border-slate-700 flex items-center justify-between sticky top-0 bg-slate-800">
              <h2 className="text-2xl font-bold text-white">Add New Track</h2>
              <button
                onClick={() => setShowModal(false)}
                className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
              >
                <X size={24} className="text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleAddTrack} className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Track Name *</label>
                  <input
                    type="text"
                    required
                    value={trackForm.name}
                    onChange={(e) => setTrackForm({...trackForm, name: e.target.value})}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                    placeholder="e.g., Full Stack Web Development"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Category *</label>
                  <select
                    value={trackForm.category}
                    onChange={(e) => setTrackForm({...trackForm, category: e.target.value})}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="Technology">Technology</option>
                    <option value="Business">Business</option>
                    <option value="Design">Design</option>
                    <option value="Marketing">Marketing</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Difficulty *</label>
                  <select
                    value={trackForm.difficulty}
                    onChange={(e) => setTrackForm({...trackForm, difficulty: e.target.value as any})}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Estimated Hours *</label>
                  <input
                    type="number"
                    required
                    value={trackForm.estimatedHours}
                    onChange={(e) => setTrackForm({...trackForm, estimatedHours: parseInt(e.target.value)})}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Modules *</label>
                  <input
                    type="number"
                    required
                    value={trackForm.modulesCount}
                    onChange={(e) => setTrackForm({...trackForm, modulesCount: parseInt(e.target.value)})}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Description *</label>
                <textarea
                  required
                  value={trackForm.description}
                  onChange={(e) => setTrackForm({...trackForm, description: e.target.value})}
                  rows={4}
                  className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500 resize-none"
                  placeholder="Describe this track..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Prerequisites</label>
                <input
                  type="text"
                  value={trackForm.prerequisites}
                  onChange={(e) => setTrackForm({...trackForm, prerequisites: e.target.value})}
                  className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                  placeholder="e.g., Basic JavaScript knowledge"
                />
              </div>

              <div className="flex gap-4 pt-4">
                <button
                  type="submit"
                  className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-semibold rounded-lg hover:shadow-lg transition-all"
                >
                  Create Track
                </button>
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 px-6 py-3 bg-slate-700 text-white font-semibold rounded-lg hover:bg-slate-600 transition-all"
                >
                  Cancel
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* Add Opportunity Modal */}
      {showModal && modalType === 'opportunity' && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-slate-800 rounded-xl border border-slate-700 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
          >
            <div className="p-6 border-b border-slate-700 flex items-center justify-between sticky top-0 bg-slate-800">
              <h2 className="text-2xl font-bold text-white">Add New Opportunity</h2>
              <button
                onClick={() => setShowModal(false)}
                className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
              >
                <X size={24} className="text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleAddOpportunity} className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Title *</label>
                  <input
                    type="text"
                    required
                    value={opportunityForm.title}
                    onChange={(e) => setOpportunityForm({...opportunityForm, title: e.target.value})}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                    placeholder="e.g., Software Engineer Intern"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Company *</label>
                  <input
                    type="text"
                    required
                    value={opportunityForm.company}
                    onChange={(e) => setOpportunityForm({...opportunityForm, company: e.target.value})}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                    placeholder="e.g., TechCorp Inc."
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Type *</label>
                  <select
                    value={opportunityForm.type}
                    onChange={(e) => setOpportunityForm({...opportunityForm, type: e.target.value as any})}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="Internship">Internship</option>
                    <option value="Full-time">Full-time</option>
                    <option value="Freelance">Freelance</option>
                    <option value="Scholarship">Scholarship</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Mode *</label>
                  <select
                    value={opportunityForm.mode}
                    onChange={(e) => setOpportunityForm({...opportunityForm, mode: e.target.value as any})}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="Remote">Remote</option>
                    <option value="Onsite">Onsite</option>
                    <option value="Hybrid">Hybrid</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Location *</label>
                  <input
                    type="text"
                    required
                    value={opportunityForm.location}
                    onChange={(e) => setOpportunityForm({...opportunityForm, location: e.target.value})}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                    placeholder="e.g., Bangalore, India"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Stipend</label>
                  <input
                    type="text"
                    value={opportunityForm.stipend}
                    onChange={(e) => setOpportunityForm({...opportunityForm, stipend: e.target.value})}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                    placeholder="e.g., ₹25,000/month"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Deadline *</label>
                  <input
                    type="date"
                    required
                    value={opportunityForm.deadline}
                    onChange={(e) => setOpportunityForm({...opportunityForm, deadline: e.target.value})}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Required Skills *</label>
                <input
                  type="text"
                  required
                  value={opportunityForm.skills}
                  onChange={(e) => setOpportunityForm({...opportunityForm, skills: e.target.value})}
                  className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                  placeholder="e.g., React, Node.js, MongoDB"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Description *</label>
                <textarea
                  required
                  value={opportunityForm.description}
                  onChange={(e) => setOpportunityForm({...opportunityForm, description: e.target.value})}
                  rows={4}
                  className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500 resize-none"
                  placeholder="Describe the opportunity..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Eligibility *</label>
                <input
                  type="text"
                  required
                  value={opportunityForm.eligibility}
                  onChange={(e) => setOpportunityForm({...opportunityForm, eligibility: e.target.value})}
                  className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                  placeholder="e.g., 2nd/3rd year students"
                />
              </div>

              <div className="flex gap-4 pt-4">
                <button
                  type="submit"
                  className="flex-1 px-6 py-3 bg-gradient-to-r from-orange-600 to-red-600 text-white font-semibold rounded-lg hover:shadow-lg transition-all"
                >
                  Create Opportunity
                </button>
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 px-6 py-3 bg-slate-700 text-white font-semibold rounded-lg hover:bg-slate-600 transition-all"
                >
                  Cancel
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
}
