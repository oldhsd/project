// app/api/admin/users/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/auth';
import User from '@/models/User';
import { connectMongoDB } from '@/lib/mongodb';

// Middleware to check admin access
async function checkAdminAccess(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.email) {
      return { authorized: false, error: 'Not authenticated' };
    }

    await connectMongoDB();
    const user = await User.findOne({ email: session.user.email });

    if (!user || user.role !== 'admin') {
      return { authorized: false, error: 'Admin access required' };
    }

    return { authorized: true, user };
  } catch (error) {
    return { authorized: false, error: 'Authentication failed' };
  }
}

// GET all users with optional filters
export async function GET(req: NextRequest) {
  try {
    const auth = await checkAdminAccess(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error }, { status: 401 });
    }

    await connectMongoDB();

    // Optional filters
    const searchParams = req.nextUrl.searchParams;
    const role = searchParams.get('role');
    const status = searchParams.get('status');
    const search = searchParams.get('search');

    let query: any = {};
    if (role && role !== 'all') query.role = role;
    if (status) query.status = status;
    if (search) {
      query.$or = [
        { email: { $regex: search, $options: 'i' } },
        { name: { $regex: search, $options: 'i' } }
      ];
    }

    const users = await User.find(query)
      .select('-password')
      .sort({ createdAt: -1 })
      .lean();

    return NextResponse.json({
      success: true,
      data: users,
      count: users.length,
      message: `Retrieved ${users.length} users`
    });
  } catch (error: any) {
    console.error('Error fetching users:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to fetch users' },
      { status: 500 }
    );
  }
}

// ============================================
// app/api/admin/users/[id]/role/route.ts
// ============================================

// PATCH - Update user role
export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const auth = await checkAdminAccess(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error }, { status: 401 });
    }

    await connectMongoDB();
    const body = await req.json();

    // Validate role
    const validRoles = ['user', 'moderator', 'admin'];
    if (!body.role || !validRoles.includes(body.role)) {
      return NextResponse.json(
        { success: false, error: 'Invalid role. Must be user, moderator, or admin' },
        { status: 400 }
      );
    }

    // Don't allow removing yourself as admin (optional safety check)
    if (params.id === auth.user._id.toString() && body.role !== 'admin') {
      return NextResponse.json(
        { success: false, error: 'Cannot remove your own admin access' },
        { status: 400 }
      );
    }

    const user = await User.findByIdAndUpdate(
      params.id,
      {
        role: body.role,
        updatedAt: new Date()
      },
      { new: true }
    ).select('-password');

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: `User role updated to ${body.role}`,
      data: user
    });
  } catch (error: any) {
    console.error('Error updating user role:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to update user role' },
      { status: 500 }
    );
  }
}

// ============================================
// app/api/admin/users/[id]/status/route.ts
// ============================================

// PATCH - Update user status (active/inactive)
export async function PATCH_STATUS(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const auth = await checkAdminAccess(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error }, { status: 401 });
    }

    await connectMongoDB();
    const body = await req.json();

    const validStatuses = ['active', 'inactive'];
    if (!body.status || !validStatuses.includes(body.status)) {
      return NextResponse.json(
        { success: false, error: 'Invalid status. Must be active or inactive' },
        { status: 400 }
      );
    }

    const user = await User.findByIdAndUpdate(
      params.id,
      {
        status: body.status,
        updatedAt: new Date()
      },
      { new: true }
    ).select('-password');

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: `User status updated to ${body.status}`,
      data: user
    });
  } catch (error: any) {
    console.error('Error updating user status:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to update user status' },
      { status: 500 }
    );
  }
}

// ============================================
// app/api/admin/users/[id]/route.ts
// ============================================

// DELETE - Delete user
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const auth = await checkAdminAccess(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error }, { status: 401 });
    }

    await connectMongoDB();

    // Don't allow deleting yourself
    if (params.id === auth.user._id.toString()) {
      return NextResponse.json(
        { success: false, error: 'Cannot delete your own account' },
        { status: 400 }
      );
    }

    const user = await User.findByIdAndDelete(params.id);

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: 'User deleted successfully',
      data: user
    });
  } catch (error: any) {
    console.error('Error deleting user:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to delete user' },
      { status: 500 }
    );
  }
}
