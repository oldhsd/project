# 🚀 Enhanced Admin Dashboard - Integration Guide

## 📋 Overview

आपके लिए एक modern, production-ready admin dashboard बनाया गया है जिसमें:

✅ **Beautiful UI** - Modern gradient design with Tailwind CSS  
✅ **Dark Theme** - Professional dark mode interface  
✅ **Admin Control** - Role-based access & user management  
✅ **Real-time Data** - Live statistics & analytics  
✅ **Complete CRUD** - Create, Read, Update, Delete operations  
✅ **Data Export** - Export to CSV  
✅ **Notifications** - Real-time toast notifications  
✅ **Responsive** - Mobile-friendly design  

---

## 🎯 Features

### Dashboard
- 📊 Analytics with key metrics
- 📈 Platform growth statistics
- 🎯 Quick action buttons

### User Management
- 👥 View all users
- 🔐 Role assignment (Admin, Moderator, User)
- 📋 User activity tracking
- 🔄 Status management

### Track Management
- ➕ Create new learning tracks
- 📝 Edit track details
- 🗑️ Delete tracks
- 📊 View enrollment statistics

### Opportunity Management
- ➕ Post new opportunities
- 📋 Manage job listings
- 🔄 Update details
- 🗑️ Remove postings

### Settings
- ⚙️ Platform configuration
- 🔒 Admin controls
- 📱 Feature toggles

---

## 📁 File Structure

```
your-project/
├── app/
│   ├── admin-ops/
│   │   ├── page.tsx               # ← Replace with enhanced version
│   │   └── access/
│   ├── api/
│   │   └── admin/
│   │       ├── middleware.ts       # ← Add admin auth middleware
│   │       ├── tracks/
│   │       │   ├── route.ts        # GET, POST tracks
│   │       │   └── [id]/
│   │       │       └── route.ts    # PATCH, DELETE track
│   │       ├── opportunities/
│   │       │   ├── route.ts        # GET, POST opportunities
│   │       │   └── [id]/
│   │       │       └── route.ts    # PATCH, DELETE opportunity
│   │       ├── users/
│   │       │   ├── route.ts        # GET users
│   │       │   └── [id]/
│   │       │       └── role/
│   │       │           └── route.ts # PATCH user role
│   │       ├── analytics/
│   │       │   └── route.ts        # GET analytics
│   │       └── export/
│   │           └── csv/
│   │               └── route.ts    # GET CSV export
│   ├── models/
│   │   ├── User.ts                # Add 'role' field
│   │   ├── Track.ts
│   │   ├── Opportunity.ts
│   │   └── Application.ts
│   └── ...
└── lib/
    └── mongodb.ts
```

---

## 🔧 Step-by-Step Integration

### Step 1: Update User Model
Add `role` field to your User model:

```typescript
// models/User.ts
import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  name: String,
  password: String,
  role: { 
    type: String, 
    enum: ['user', 'moderator', 'admin'],
    default: 'user'
  },
  status: { 
    type: String, 
    enum: ['active', 'inactive'],
    default: 'active'
  },
  lastActive: { type: Date, default: Date.now },
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.models.User || mongoose.model('User', userSchema);
```

### Step 2: Replace Admin Page
1. Replace `/app/admin-ops/page.tsx` with the new enhanced version
2. Make sure it's a client component (has `'use client'`)
3. Verify imports (Lucide React, Framer Motion must be installed)

### Step 3: Create API Routes
Create the following API route files:

#### app/api/admin/middleware.ts
```typescript
// Handles admin authentication
import { getServerSession } from 'next-auth';
import { authOptions } from '@/auth';

export async function adminAuth(req) {
  const session = await getServerSession(authOptions);
  if (!session) {
    return { error: 'Unauthorized', status: 401 };
  }
  // Add role check here
  return null;
}
```

#### app/api/admin/tracks/route.ts
```typescript
// GET all tracks
// POST new track
```

#### app/api/admin/opportunities/route.ts
```typescript
// GET all opportunities
// POST new opportunity
```

#### app/api/admin/users/route.ts
```typescript
// GET all users
```

#### app/api/admin/users/[id]/role/route.ts
```typescript
// PATCH user role
```

### Step 4: Update NextAuth Configuration
Ensure your auth.ts has the MongoDB adapter:

```typescript
// auth.ts
import { authOptions } from 'next-auth';
import { MongoDBAdapter } from '@auth/mongodb-adapter';
import CredentialsProvider from 'next-auth/providers/credentials';
import clientPromise from '@/lib/mongodb';

export const authOptions = {
  adapter: MongoDBAdapter(clientPromise),
  providers: [
    CredentialsProvider({
      // Your existing provider config
    })
  ],
  callbacks: {
    async session({ session, user }) {
      // Add user role to session
      return session;
    }
  }
};
```

### Step 5: Protect Admin Routes
Add middleware to protect `/admin-ops` route:

```typescript
// middleware.ts
import { getToken } from 'next-auth/jwt';
import { NextRequest, NextResponse } from 'next/server';

export async function middleware(request: NextRequest) {
  const path = request.nextUrl.pathname;
  
  if (path.startsWith('/admin-ops')) {
    const token = await getToken({ req: request });
    
    if (!token || token.role !== 'admin') {
      return NextResponse.redirect(new URL('/login', request.url));
    }
  }
  
  return NextResponse.next();
}

export const config = {
  matcher: ['/admin-ops/:path*']
};
```

---

## 🔐 Admin Role Management

### How to Make First User Admin

**Option 1: Manually via MongoDB**
```javascript
db.users.updateOne(
  { email: 'your-email@gmail.com' },
  { $set: { role: 'admin' } }
)
```

**Option 2: Create Admin Script**
```typescript
// scripts/makeAdmin.ts
import { connectMongoDB } from '@/lib/mongodb';
import User from '@/models/User';

async function makeAdmin(email: string) {
  await connectMongoDB();
  const user = await User.findOneAndUpdate(
    { email },
    { role: 'admin' },
    { new: true }
  );
  console.log('Admin created:', user);
}

makeAdmin('your-email@gmail.com');
```

### Role Hierarchy
```
┌─────────────────────────────┐
│        ADMIN (Superuser)    │
│  - Full platform control    │
│  - User management          │
│  - Content moderation       │
└─────────────────────────────┘
         ↓
┌─────────────────────────────┐
│      MODERATOR              │
│  - Content management       │
│  - Application review       │
│  - Limited user control     │
└─────────────────────────────┘
         ↓
┌─────────────────────────────┐
│        USER (Default)       │
│  - Browse content           │
│  - Apply for opportunities  │
│  - View enrollments         │
└─────────────────────────────┘
```

---

## 🎨 Customization

### Change Color Scheme
Find gradient classes like `from-blue-600 to-cyan-600` and replace:
- Blue/Cyan → Track management
- Orange/Red → Opportunity management
- Green/Emerald → Active status
- Purple/Pink → General features

### Adjust Sidebar Width
```typescript
className={`${sidebarOpen ? 'w-64' : 'w-20'} ...`}
// Change w-64 to w-72 for wider sidebar
// Change w-20 to w-24 for wider collapsed state
```

### Modify Analytics Cards
In the `analytics` state, update the statistics calculation:
```typescript
setAnalytics({
  totalUsers: usersCount,
  totalTracks: tracksCount,
  totalOpportunities: oppCount,
  activeEnrollments: enrollmentsCount,
  pendingApplications: applicationsCount,
  platformGrowth: ((newThisMonth / totalUsers) * 100).toFixed(1)
});
```

---

## 🔌 API Endpoints

### Tracks
```
GET    /api/admin/tracks              - List all tracks
POST   /api/admin/tracks              - Create track
PATCH  /api/admin/tracks/[id]         - Update track
DELETE /api/admin/tracks/[id]         - Delete track
```

### Opportunities
```
GET    /api/admin/opportunities       - List all opportunities
POST   /api/admin/opportunities       - Create opportunity
PATCH  /api/admin/opportunities/[id]  - Update opportunity
DELETE /api/admin/opportunities/[id]  - Delete opportunity
```

### Users
```
GET    /api/admin/users               - List all users
PATCH  /api/admin/users/[id]/role     - Change user role
```

### Analytics
```
GET    /api/admin/analytics           - Get platform statistics
```

### Export
```
GET    /api/admin/export/csv?type=users          - Export users
GET    /api/admin/export/csv?type=tracks         - Export tracks
GET    /api/admin/export/csv?type=opportunities  - Export opportunities
```

---

## 🧪 Testing the Dashboard

1. **Login as Admin**
   ```
   Email: your-admin-email@gmail.com
   Password: your-password
   ```

2. **Test Features**
   - ✅ Navigate tabs (Overview, Users, Tracks, Opportunities, Settings)
   - ✅ Create new track
   - ✅ Create new opportunity
   - ✅ Change user roles
   - ✅ Export data as CSV
   - ✅ View analytics

3. **Check Notifications**
   - Success messages on create/update/delete
   - Error messages for failed operations

---

## 🐛 Troubleshooting

### "Unauthorized" Error
- Check if user is logged in
- Verify user.role === 'admin' in database
- Check session configuration in NextAuth

### Modal Not Opening
- Verify onClick handler is connected
- Check if `showModal` state is updating
- Ensure modal render condition is correct

### API Not Working
- Check CORS configuration
- Verify MongoDB connection
- Check request headers include auth token
- Review server logs

### Styles Not Loading
- Verify Tailwind CSS is configured
- Check className is not using conditional logic correctly
- Ensure gradients are using standard Tailwind classes

---

## 📱 Features Summary

| Feature | Status | Notes |
|---------|--------|-------|
| Dashboard Analytics | ✅ | Displays key metrics |
| User Management | ✅ | Role-based access control |
| Track Management | ✅ | Full CRUD operations |
| Opportunity Management | ✅ | Create/Edit/Delete postings |
| Export to CSV | ✅ | Download user/track/opp data |
| Notifications | ✅ | Toast messages |
| Dark Mode | ✅ | Built-in |
| Responsive Design | ✅ | Mobile-friendly |
| Admin Auth | ✅ | Protected routes |

---

## 📞 Support

If you need help:
1. Check the troubleshooting section
2. Review API endpoints configuration
3. Verify MongoDB collections exist
4. Check NextAuth session setup
5. Review console for error messages

---

## 🎉 You're Ready!

Your admin dashboard is now ready to use. Here's what you can do:

1. ✅ Manage users and assign roles
2. ✅ Create and manage learning tracks
3. ✅ Post opportunities (internships, jobs)
4. ✅ View platform analytics
5. ✅ Export data
6. ✅ Control everything from one place

**Happy Admin-ing!** 🚀
