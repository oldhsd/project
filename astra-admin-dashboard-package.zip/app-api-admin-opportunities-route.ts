// app/api/admin/opportunities/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/auth';
import Opportunity from '@/models/Opportunity';
import User from '@/models/User';
import { connectMongoDB } from '@/lib/mongodb';

// Middleware to check admin access
async function checkAdminAccess(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.email) {
      return { authorized: false, error: 'Not authenticated' };
    }

    await connectMongoDB();
    const user = await User.findOne({ email: session.user.email });

    if (!user || user.role !== 'admin') {
      return { authorized: false, error: 'Admin access required' };
    }

    return { authorized: true, user };
  } catch (error) {
    return { authorized: false, error: 'Authentication failed' };
  }
}

// GET all opportunities with optional filters
export async function GET(req: NextRequest) {
  try {
    const auth = await checkAdminAccess(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error }, { status: 401 });
    }

    await connectMongoDB();
    
    // Optional filters
    const searchParams = req.nextUrl.searchParams;
    const type = searchParams.get('type');
    const mode = searchParams.get('mode');
    const status = searchParams.get('status');

    let query: any = {};
    if (type) query.type = type;
    if (mode) query.mode = mode;
    if (status) query.status = status;

    const opportunities = await Opportunity.find(query).sort({ createdAt: -1 }).lean();

    return NextResponse.json({
      success: true,
      data: opportunities,
      count: opportunities.length,
      message: `Retrieved ${opportunities.length} opportunities`
    });
  } catch (error: any) {
    console.error('Error fetching opportunities:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to fetch opportunities' },
      { status: 500 }
    );
  }
}

// POST - Create new opportunity
export async function POST(req: NextRequest) {
  try {
    const auth = await checkAdminAccess(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error }, { status: 401 });
    }

    await connectMongoDB();
    const body = await req.json();

    // Validation
    const requiredFields = ['title', 'company', 'type', 'mode', 'location', 'deadline', 'description'];
    for (const field of requiredFields) {
      if (!body[field]) {
        return NextResponse.json(
          { success: false, error: `${field} is required` },
          { status: 400 }
        );
      }
    }

    const opportunity = new Opportunity({
      title: body.title,
      company: body.company,
      type: body.type, // Internship, Full-time, Freelance, Scholarship
      mode: body.mode, // Remote, Onsite, Hybrid
      location: body.location,
      stipend: body.stipend || 'Not specified',
      description: body.description,
      skills: body.skills || '',
      eligibility: body.eligibility || '',
      deadline: new Date(body.deadline),
      status: body.status || 'active',
      applicationsCount: 0,
      createdAt: new Date(),
      createdBy: auth.user._id
    });

    await opportunity.save();

    return NextResponse.json({
      success: true,
      message: 'Opportunity created successfully',
      data: opportunity
    }, { status: 201 });
  } catch (error: any) {
    console.error('Error creating opportunity:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to create opportunity' },
      { status: 500 }
    );
  }
}

// ============================================
// app/api/admin/opportunities/[id]/route.ts
// ============================================

// PATCH - Update opportunity
export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const auth = await checkAdminAccess(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error }, { status: 401 });
    }

    await connectMongoDB();
    const body = await req.json();

    const opportunity = await Opportunity.findByIdAndUpdate(
      params.id,
      {
        ...body,
        updatedAt: new Date()
      },
      { new: true }
    );

    if (!opportunity) {
      return NextResponse.json(
        { success: false, error: 'Opportunity not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: 'Opportunity updated successfully',
      data: opportunity
    });
  } catch (error: any) {
    console.error('Error updating opportunity:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to update opportunity' },
      { status: 500 }
    );
  }
}

// DELETE - Delete opportunity
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const auth = await checkAdminAccess(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error }, { status: 401 });
    }

    await connectMongoDB();
    const opportunity = await Opportunity.findByIdAndDelete(params.id);

    if (!opportunity) {
      return NextResponse.json(
        { success: false, error: 'Opportunity not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: 'Opportunity deleted successfully',
      data: opportunity
    });
  } catch (error: any) {
    console.error('Error deleting opportunity:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to delete opportunity' },
      { status: 500 }
    );
  }
}
